import React,{Component} from 'react';

class Page1 extends Component{
    render(){
        return(
            <div>
                
            </div>
        )
    }
}
export default Page1;