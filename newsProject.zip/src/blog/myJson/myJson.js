import first from '../images/ft-slider-img1.jpg';
import img from '../images/ft-slider-img2.jpg';
import img3 from '../images/ft-slider-img3.jpg';
import img4 from '../images/ft-slider-img4.jpg';
import img5 from '../images/ft-slider-img5.jpg';
import img6 from '../images/ft-slider-img6.jpg';
import img7 from '../images/ft-slider-img7.jpg';
import img8 from '../images/ft-slider-img8.jpg';

export const baza=[
    {
      img:first,
      title:`We Tried The New Taco Bell Chicken Nuggets And Here's What Happened`,
      deta:`06, August 2016`,
      link:`WORLd`,
      like:124,
      message:16
    },
    {
        img:img,
        title:`Cook A Stir-Fry And We’ll Guess Your Age And Relationship Status`,
        deta:`06, August 2016`,
        link:`INTERNET`,
        like:124,
        message:16
      },
      {
        img:img3,
        title:`We Tried The New Taco Bell Chicken Nuggets And Here's What Happened`,
        deta:`06, August 2016`,
        link:`WORLd`,
        like:124,
        message:16
      },
      {
        img:img4,
        title:`We Tried The New Taco Bell Chicken Nuggets And Here's What Happened`,
        deta:`06, August 2016`,
        link:`INTERNET`,
        like:124,
        message:16
      },
      {
        img:img5,
        title:`We Tried The New Taco Bell Chicken Nuggets And Here's What Happened`,
        deta:`06, August 2016`,
        link:`WORLd`,
        like:124,
        message:16
      },
      {
        img:img6,
        title:`We Tried The New Taco Bell Chicken Nuggets And Here's What Happened`,
        deta:`06, August 2016`,
        link:`INTERNET`,
        like:124,
        message:16
      },
      {
        img:img7,
        title:`We Tried The New Taco Bell Chicken Nuggets And Here's What Happened`,
        deta:`06, August 2016`,
        link:`WORLd`,
        like:124,
        message:16
      },
      {
        img:img8,
        title:`We Tried The New Taco Bell Chicken Nuggets And Here's What Happened`,
        deta:`06, August 2016`,
        link:`INTERNET`,
        like:124,
        message:16
      }
]