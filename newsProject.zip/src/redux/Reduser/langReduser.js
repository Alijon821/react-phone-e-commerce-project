import {GetLanguage,  SetLocalstorage} from "../../Utilitil";

const initialState = {
    uzLang: true,
};

export const langReducer = (state = initialState, action) => {
    switch (action.type) {
        case "uzlang":

           SetLocalstorage("TemurbekIsmoilov20000","Uzbekcha")

        // {GetLanguage("enLang")?DeleteLocalStorage("enLang"): SetLocalstorage("TemurbekIsmoilov2000","uzLang")}
        //     return { uzLang: GetLanguage("uzLang")? true:false};
                return {uzLang: true}
        case "enLang":

            SetLocalstorage("TemurbekIsmoilov20000","Inglizcha")
        // {GetLanguage("uzLang")?DeleteLocalStorage("uzLang"): SetLocalstorage("TemurbekIsmoilov2000","enLang")}
        //     return { uzLang: GetLanguage("enLang")? false:true };
                return {uzLang: false}

        default:
            // if (getValue()){
            //     if (getValue()==='Uzbekcha'){
            //
            //     }
            // }
        {!GetLanguage()?SetLocalstorage("TemurbekIsmoilov20000","Uzbekcha"):SetLocalstorage("TemurbekIsmoilov20000","Inglizcha")}
        // {GetLanguage("uzLang")?DeleteLocalStorage("uzLang"): SetLocalstorage("TemurbekIsmoilov2000","enLang")}
            return {
                uzLang:true
            };
    }
};