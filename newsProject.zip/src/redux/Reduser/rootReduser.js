import { combineReducers } from "redux";
import {langReducer} from "./langReduser";
import {GetLanguage, SetLocalstorage} from "../../Utilitil";


export const rootReducer = combineReducers({
    uzLang:langReducer,
}
)
