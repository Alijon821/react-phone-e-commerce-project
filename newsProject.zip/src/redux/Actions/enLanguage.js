
export const enLanguage=()=>{
    return {
        type:'enLang',
    }

}