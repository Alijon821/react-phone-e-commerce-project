export const uzLanguage=()=>{
    return {
        type :'uzLang',
    }

}