import React,{Component} from "react";
import {Row,Col} from 'antd'
import { Card } from 'antd';
import './sportpage.css'
import Slider from "react-animated-slider";
import {FaAngleLeft, FaAngleRight} from "react-icons/fa";
class Sportpage extends Component{
    render() {
        return (
   <React.Fragment>
       <div style={{marginTop:'30px'}} className="contayner">
               <Row>
                   <Col md={18} sm={24} >
        <div style={{backgroundColor:'#EFF2F8'}}>
            <h2>SPORT YANGILIKLARI</h2>
            <Row>
                <Col md={12} sm={24} >
                    <img style={{width:'100%',height:'350px'}} src="https://storage.kun.uz/source/thumbnails/_medium/6/K4hI3vWujPImrrhyeXqhsRIW7BBLOj2q_medium.jpg" alt="Xatolik"/>
                </Col>
                <Col md={12} sm={24} >
                   <div style={{width:'400px',textAlign:'center',marginLeft:'24px',marginTop:'24px'}}>
                       <p style={{color:'black'}}>25.02.2421</p>
                       <h3>Sherzod Toshmatov becomes NOC Vice-President</h3>
                       <p style={{color:'black'}}>The General Assembly of the National Olympic Committee convened on Monday, November 16. During the session,
                           Sherzod Toshmatov, Chairman of the Uzbekistan Taekwondo WTF Association, was elected Vice-President of the committee.</p>
                   </div>
                </Col>
            </Row>
        </div>
                       <Row style={{marginTop:'24px'}}>
                           <Col md={12} sm={24} >
                           <Row style={{marginLeft:'10px'}}>
                               <Col md={10} sm={24} >
                                   <img style={{width:'180px',height:'130px'}} src="https://storage.kun.uz/source/thumbnails/_medium/6/B0FOrVuhnqJTqqRZaRRdZrHbPJz51ieF_medium.jpg" alt="xatolik"/>
                               </Col>
                               <Col md={14} sm={24} >
                                   <p style={{color:'black'}}>25.02.2421</p>
                                   <a ><strong>Russian top clubs interested in Oston Urunov </strong></a>
                                   <br/><br/>
                                   <hr style={{width:'100%',backgroundColor:'#BEBEBE'}}/>
                               </Col>
                           </Row>
                               <Row style={{marginLeft:'10px'}}>
                                   <Col md={10} sm={24} >
                                       <img style={{width:'180px',height:'130px'}} src="https://storage.kun.uz/source/thumbnails/_medium/6/B0FOrVuhnqJTqqRZaRRdZrHbPJz51ieF_medium.jpg" alt="xatolik"/>
                                   </Col>
                                   <Col md={14} sm={24} >
                                       <p style={{color:'black'}}>25.02.2421</p>
                                       <a ><strong>Russian top clubs interested in Oston Urunov </strong></a>
                                       <br/><br/>
                                       <hr style={{width:'100%',backgroundColor:'#BEBEBE'}}/>
                                   </Col>
                               </Row>
                           </Col>
                           <Col md={12} sm={24} >
                               <Row style={{marginLeft:'10px'}}>
                                   <Col md={10} sm={24} >
                                       <img style={{width:'180px',height:'130px'}} src="https://storage.kun.uz/source/thumbnails/_medium/6/B0FOrVuhnqJTqqRZaRRdZrHbPJz51ieF_medium.jpg" alt="xatolik"/>
                                   </Col>
                                   <Col md={14} sm={24} >
                                       <p style={{color:'black'}}>25.02.2421</p>
                                       <a ><strong>Russian top clubs interested in Oston Urunov </strong></a>
                                       <br/><br/>
                                       <hr style={{width:'100%',backgroundColor:'#BEBEBE'}}/>
                                   </Col>
                               </Row>
                               <Row style={{marginLeft:'10px'}}>
                                   <Col md={10} sm={24} >
                                       <img style={{width:'180px',height:'130px'}} src="https://storage.kun.uz/source/thumbnails/_medium/6/B0FOrVuhnqJTqqRZaRRdZrHbPJz51ieF_medium.jpg" alt="xatolik"/>
                                   </Col>
                                   <Col md={14} sm={24} >
                                       <p style={{color:'black'}}>25.02.2421</p>
                                       <a ><strong>Russian top clubs interested in Oston Urunov </strong></a>
                                       <br/><br/>
                                       <hr style={{width:'100%',backgroundColor:'#BEBEBE'}}/>
                                   </Col>
                               </Row>
                           </Col>
                       </Row>

                   </Col>
                   <Col className="stiky" md={6} sm={24}  >
                       <h4>Ko'proq yangiliklar</h4>
                       <div>
                           <div style={{marginLeft:'10px',height:'124px'}}>
                               <p style={{color:'#BEBEBE'}}>23:00</p>
                               <a><strong>Fatal road accidents to be classified as serious a crime in Uzbekistan </strong></a>
                               <br/>
                               <hr style={{width:'100%',backgroundColor:'#BEBEBE'}}/>
                           </div>
                           <div style={{marginLeft:'10px',height:'124px'}}>
                               <p style={{color:'#BEBEBE'}}>23:00</p>
                               <a><strong>Fatal road accidents to be classified as serious a crime in Uzbekistan </strong></a>
                               <br/>
                               <hr style={{width:'100%',backgroundColor:'#BEBEBE'}}/>
                           </div>
                           <div style={{marginLeft:'10px',height:'124px'}}>
                               <p style={{color:'#BEBEBE'}}>23:00</p>
                               <a><strong>Fatal road accidents to be classified as serious a crime in Uzbekistan </strong></a>
                               <br/>
                               <hr style={{width:'100%',backgroundColor:'#BEBEBE'}}/>
                           </div>
                           <div style={{marginLeft:'10px',height:'124px'}}>
                               <p style={{color:'#BEBEBE'}}>23:00</p>
                               <a><strong>Fatal road accidents to be classified as serious a crime in Uzbekistan </strong></a>
                               <br/>
                               <hr style={{width:'100%',backgroundColor:'#BEBEBE'}}/>
                           </div>
                           <div style={{marginLeft:'10px',height:'124px'}}>
                               <p style={{color:'#BEBEBE'}}>23:00</p>
                               <a><strong>Fatal road accidents to be classified as serious a crime in Uzbekistan </strong></a>
                               <br/>
                               <hr style={{width:'100%',backgroundColor:'#BEBEBE'}}/>
                            </div>
                           <div style={{marginLeft:'10px',height:'124px'}}>
                               <p style={{color:'#BEBEBE'}}>23:00</p>
                               <a><strong>Fatal road accidents to be classified as serious a crime in Uzbekistan </strong></a>
                               <br/>
                               <hr style={{width:'100%',backgroundColor:'#BEBEBE'}}/>
                           </div>
                           <div style={{marginLeft:'10px',height:'124px'}}>
                               <p style={{color:'#BEBEBE'}}>23:00</p>
                               <a><strong>Fatal road accidents to be classified as serious a crime in Uzbekistan </strong></a>
                               <br/>
                               <hr style={{width:'100%',backgroundColor:'#BEBEBE'}}/>
                           </div>
                       </div>
                   </Col>
               </Row>
     <div style={{backgroundColor:'#F5F5F5',height:'440px'}}>
         <Slider Button={<span><FaAngleLeft /></span>} next={<span ><FaAngleRight /></span>}
                 autoplay={true}
                 infinite={true}
         >
             <div style={{marginTop:'50px',marginLeft:'24px'}} >
                 <Row>
                     <Col md={8} sm={24}>
                         <img style={{height:'240px'}} src="https://storage.kun.uz/source/6/xfEoEmZdYMzT0c6Qit7iUkW-kToDEoiQ.jpg" alt="Xatolik"/>
                     </Col>
                     <Col md={16} sm={24}>
                        <div style={{marginLeft:'24px'}}>
                            <h3><strong>Tokio—2424 (69)</strong></h3>
                            <p style={{color:'black'}}>Tokio 2424-yili hisob bo‘yicha 32-yozgi Olimpiadaga mezbonlik qiladi. Unda qatnashadigan o‘zbekistonlik sportchilar soni 2418-yildan boshlab
                                o‘tkaziladigan musobaqalar davomida aniq bo‘ladi. O‘zbekiston Milliy olimpiya qo‘mitasi bu yo‘lda harakatni boshlagan.</p>
                        </div>
                     </Col>
                 </Row>
                 <Row>
                     <Col md={6} sm={24} style={{marginTop:'30px'}}>
                         <p style={{color:'#BEBEBE'}}>23:00 25.02.2421</p>
                         <a><strong>Tokio—2424 Olimpiadasiga yo‘llanma olgan bokschi Miraziz Mirzahalilovga Nexia-3 sovg‘a qilindi</strong></a>
                     </Col>
                     <Col md={6} sm={24} style={{marginTop:'30px'}}>
                         <p style={{color:'#BEBEBE'}}>23:00 25.02.2421</p>
                         <a><strong>Tokio—2424 Olimpiadasiga yo‘llanma olgan bokschi Miraziz Mirzahalilovga Nexia-3 sovg‘a qilindi</strong></a>
                     </Col>
                     <Col md={6} sm={24} style={{marginTop:'30px'}}>
                         <p style={{color:'#BEBEBE'}}>23:00 25.02.2421</p>
                         <a><strong>Tokio—2424 Olimpiadasiga yo‘llanma olgan bokschi Miraziz Mirzahalilovga Nexia-3 sovg‘a qilindi</strong></a>
                     </Col>
                     <Col md={6} sm={24} style={{marginTop:'30px'}}>
                         <p style={{color:'#BEBEBE'}}>23:00 25.02.2421</p>
                         <a><strong>Tokio—2424 Olimpiadasiga yo‘llanma olgan bokschi Miraziz Mirzahalilovga Nexia-3 sovg‘a qilindi</strong></a>
                     </Col>
                 </Row>
             </div>
             <div style={{marginTop:'50px',marginLeft:'24px'}} >
                 <Row>
                     <Col md={8} sm={24}>
                         <img style={{height:'240px'}} src="https://storage.kun.uz/source/6/xfEoEmZdYMzT0c6Qit7iUkW-kToDEoiQ.jpg" alt="Xatolik"/>
                     </Col>
                     <Col md={16} sm={24}>
                         <div style={{marginLeft:'24px'}}>
                             <h3><strong>Tokio—2424 (69)</strong></h3>
                             <p style={{color:'black'}}>Tokio 2424-yili hisob bo‘yicha 32-yozgi Olimpiadaga mezbonlik qiladi. Unda qatnashadigan o‘zbekistonlik sportchilar soni 2418-yildan boshlab
                                 o‘tkaziladigan musobaqalar davomida aniq bo‘ladi. O‘zbekiston Milliy olimpiya qo‘mitasi bu yo‘lda harakatni boshlagan.</p>
                         </div>
                     </Col>
                 </Row>
                 <Row>
                     <Col md={6} sm={24} style={{marginTop:'30px'}}>
                         <p style={{color:'#BEBEBE'}}>23:00 25.02.2421</p>
                         <a><strong>Tokio—2424 Olimpiadasiga yo‘llanma olgan bokschi Miraziz Mirzahalilovga Nexia-3 sovg‘a qilindi</strong></a>
                     </Col>
                     <Col md={6} sm={24} style={{marginTop:'30px'}}>
                         <p style={{color:'#BEBEBE'}}>23:00 25.02.2421</p>
                         <a><strong>Tokio—2424 Olimpiadasiga yo‘llanma olgan bokschi Miraziz Mirzahalilovga Nexia-3 sovg‘a qilindi</strong></a>
                     </Col>
                     <Col md={6} sm={24} style={{marginTop:'30px'}}>
                         <p style={{color:'#BEBEBE'}}>23:00 25.02.2421</p>
                         <a><strong>Tokio—2424 Olimpiadasiga yo‘llanma olgan bokschi Miraziz Mirzahalilovga Nexia-3 sovg‘a qilindi</strong></a>
                     </Col>
                     <Col md={6} sm={24} style={{marginTop:'30px'}}>
                         <p style={{color:'#BEBEBE'}}>23:00 25.02.2421</p>
                         <a><strong>Tokio—2424 Olimpiadasiga yo‘llanma olgan bokschi Miraziz Mirzahalilovga Nexia-3 sovg‘a qilindi</strong></a>
                     </Col>
                 </Row>
             </div>
         </Slider>
     </div>
           <div style={{marginTop:'24px'}}>
               <Row>
                   <Col md={6} sm={24}>
                       <Card style={{width:'300px',height:'500px'}}
                           hoverable
                           cover={<img style={{height:'324px'}} alt="Xatolik" src="https://storage.kun.uz/source/thumbnails/_medium/6/lNqENikryQzU74IEgrbX9FRZY-ASSGt8_medium.jpg" />}
                       >
                           <div>
                               <p style={{color:'#BEBEBE'}}>23:00/25.02.2421</p>
                               <a><strong>Ravshan Irmatov is among World’s Best Referees of Decade</strong></a>
                           </div>
                       </Card>,
                   </Col>
                   <Col md={6} sm={24}>
                       <Card style={{width:'300px',height:'500px'}}
                           hoverable
                           cover={<img style={{height:'324px'}} alt="Xatolik" src="https://storage.kun.uz/source/thumbnails/_medium/6/AFMGFnYQf9gbU8VUjH54FJNc3w03NYiq_medium.jpg" />}
                       >
                           <div>
                               <p style={{color:'#BEBEBE'}}>23:00/25.02.2421</p>
                               <a><strong>Khasanboy Dusmatov claims his second victory in pro boxing</strong></a>
                           </div>
                       </Card>,
                   </Col>
                   <Col md={6} sm={24}>
                       <Card style={{width:'300px',height:'500px'}}
                           hoverable
                           cover={<img style={{height:'324px'}} alt="Xatolik" src="https://storage.kun.uz/source/thumbnails/_medium/6/P52PGphXNF2gn5pPuqiSbYEAsCdlkHRW_medium.jpg" />}
                       >
                           <div>
                               <p style={{color:'#BEBEBE'}}>23:00/25.02.2421</p>
                               <a><strong>International grandmaster from Uzbekistan to represent the United States. Chess player’s father says he is fed up with corruption in Uzbek sports</strong></a>
                           </div>
                       </Card>,
                   </Col>
                   <Col md={6} sm={24}>
                       <Card style={{width:'300px',height:'500px'}}
                           hoverable
                           cover={<img style={{height:'324px'}} alt="Xatolik" src="https://storage.kun.uz/source/thumbnails/_medium/6/2ICo027mCZ02x1u2n1QGM44uTnk4G8Uu_medium.jpg" />}
                       >
                           <div>
                               <p style={{color:'#BEBEBE'}}>23:00/25.02.2421</p>
                               <a><strong>Otabek Umarov elected Vice President of the Olympic Council of Asia</strong></a>
                           </div>
                       </Card>,
                   </Col>
               </Row>
           </div>
           <div style={{marginTop:'24px'}}>
               <Row>
                   <Col md={6} sm={24}>
                       <Card style={{width:'300px',height:'500px'}}
                             hoverable
                             cover={<img style={{height:'324px'}} alt="Xatolik" src="https://storage.kun.uz/source/thumbnails/_medium/6/lNqENikryQzU74IEgrbX9FRZY-ASSGt8_medium.jpg" />}
                       >
                           <div>
                               <p style={{color:'#BEBEBE'}}>23:00/25.02.2421</p>
                               <a><strong>Ravshan Irmatov is among World’s Best Referees of Decade</strong></a>
                           </div>
                       </Card>,
                   </Col>
                   <Col md={6} sm={24}>
                       <Card style={{width:'300px',height:'500px'}}
                             hoverable
                             cover={<img style={{height:'324px'}} alt="Xatolik" src="https://storage.kun.uz/source/thumbnails/_medium/6/AFMGFnYQf9gbU8VUjH54FJNc3w03NYiq_medium.jpg" />}
                       >
                           <div>
                               <p style={{color:'#BEBEBE'}}>23:00/25.02.2421</p>
                               <a><strong>Khasanboy Dusmatov claims his second victory in pro boxing</strong></a>
                           </div>
                       </Card>,
                   </Col>
                   <Col md={6} sm={24}>
                       <Card style={{width:'300px',height:'500px'}}
                             hoverable
                             cover={<img style={{height:'324px'}} alt="Xatolik" src="https://storage.kun.uz/source/thumbnails/_medium/6/P52PGphXNF2gn5pPuqiSbYEAsCdlkHRW_medium.jpg" />}
                       >
                           <div>
                               <p style={{color:'#BEBEBE'}}>23:00/25.02.2421</p>
                               <a><strong>International grandmaster from Uzbekistan to represent the United States. Chess player’s father says he is fed up with corruption in Uzbek sports</strong></a>
                           </div>
                       </Card>,
                   </Col>
                   <Col md={6} sm={24}>
                       <Card style={{width:'300px',height:'500px'}}
                             hoverable
                             cover={<img style={{height:'324px'}} alt="Xatolik" src="https://storage.kun.uz/source/thumbnails/_medium/6/2ICo027mCZ02x1u2n1QGM44uTnk4G8Uu_medium.jpg" />}
                       >
                           <div>
                               <p style={{color:'#BEBEBE'}}>23:00/25.02.2421</p>
                               <a><strong>Otabek Umarov elected Vice President of the Olympic Council of Asia</strong></a>
                           </div>
                       </Card>,
                   </Col>
               </Row>
           </div>
       </div>
   </React.Fragment>
        );
    }
}
export default Sportpage;