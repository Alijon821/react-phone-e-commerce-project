import React, {Component} from 'react';
import Carousel from "react-multi-carousel";
import 'bootstrap/dist/css/bootstrap.min.css'
import 'react-multi-carousel/lib/styles.css';
import "react-multi-carousel/lib/styles.css";
import SliderImg1 from '../images/ltv-img1.jpg';
import SliderImg2 from '../images/ltv-img2.jpg';
import SliderImg3 from '../images/ltv-img3.jpg';
import SliderImg4 from '../images/ltv-img4.jpg';
import {ClockCircleOutlined, EyeOutlined, HeartOutlined, PlayCircleOutlined} from '@ant-design/icons';
// import MyModal from '../components/modal-video';
import '../carousel/modal-video.css';
import '../carousel/carusel.css'
import ModalVideo from 'react-modal-video';
import InfiniteCarousel from "react-leaf-carousel";

const responsive = {
    desktop: {
        breakpoint: {max: 3000, min: 1024},
        items: 3,
        slidesToSlide: 1 // optional, default to 1.
    },
    tablet: {
        breakpoint: {max: 1024, min: 464},
        items: 2,
        slidesToSlide: 1 // optional, default to 1.
    },
    mobile: {
        breakpoint: {max: 464, min: 0},
        items: 1,
        slidesToSlide: 1 // optional, default to 1.
    }
};

class MyCarusel extends Component {

    constructor() {
        super()
        this.state = {
            isOpen: false
        }
        this.openModal = this.openModal.bind(this)
    }

    openModal() {
        this.setState({isOpen: true})
    }

    render() {
        return (

            <div className='zz' style={{marginBottom:'220px'}}>

                <div className='posAbs'>

                    <div className='clear'>

                    </div>
                    <div className='ccc'>
                        <div>
                           <div className="container view_content">
                                <div className="row">
                                    <div className="position-relative col-md-12 d-flex justify-content-between">
                                        <h3 className='text-light'>LETEST VIDEO</h3>
                                        <div> <a href="#">view all</a></div>

                                    </div>
                                </div>
                           </div>
                            <Carousel

                                className='container qq'
                                swipeable={true}
                                draggable={true}
                                showDots={true}
                                responsive={responsive}
                                ssr={true} // means to render carousel on server-side.
                                infinite={true}
                                // autoPlay={this.props.deviceType !== "mobile" ? true : false}
                                // autoPlaySpeed={4000}
                                keyBoardControl={true}
                                customTransition="transform 1000ms ease-in-out"
                                transitionDuration={500}
                                containerClass="carousel-container"
                                removeArrowOnDeviceType={["tablet", "mobile"]}
                                deviceType={this.props.deviceType}
                                dotListClass="react-multi-carousel-dot-list"
                                // autoPlay={true}
                                centerMode={true}
                                //   itemClass="carousel-item-padding-40-px"
                            >

                                <div className='carusel-Item' >

                                    <img  style={{ position: 'relative',width:"100%" }} src={SliderImg1} />
                                    <a className='PlayA' onClick={this.openModal} href='#'>
                                        <PlayCircleOutlined  className='playIcon shadow-sm rounded '  style={{ fontSize: '40px', color: 'white' }} /></a>
                                    <span><ClockCircleOutlined className='iconClock' />  Nov 1,2020</span>
                                    <span><EyeOutlined className='iconClock' /> 15k</span>
                                    <span><HeartOutlined className='iconClock' /> 278</span>

                                    <br />
                                    <a className='sliderInfo' href='#'>
                                        <p>Japan in four Gorgeous <br /> Pokemon-Themed Colors</p>
                                    </a>


                                </div>
                                <div className='carusel-Item' >
                                    <img src={SliderImg2} />
                                    <a href='#' className='PlayA'><PlayCircleOutlined onClick={this.openModal} className='playIcon' style={{ fontSize: '40px', color: 'white' }} /></a>
                                    <span><ClockCircleOutlined className='iconClock' />  Nov 1,2020</span>
                                    <span><EyeOutlined className='iconClock' /> 15k</span>
                                    <span><HeartOutlined className='iconClock' /> 278</span>

                                    <br />
                                    <a className='sliderInfo' href='#'>
                                        <p>Japan in four Gorgeous <br /> Pokemon-Themed Colors</p>
                                    </a>

                                </div>
                                <div className='carusel-Item' >
                                    <img src={SliderImg3} />
                                    <a href='#' className='PlayA'><PlayCircleOutlined onClick={this.openModal} className='playIcon' style={{ fontSize: '40px', color: 'white' }} /></a>
                                    <span><ClockCircleOutlined className='iconClock' />  Nov 1,2020</span>
                                    <span><EyeOutlined className='iconClock' /> 15k</span>
                                    <span><HeartOutlined className='iconClock' /> 278</span>

                                    <br />
                                    <a className='sliderInfo' href='#'>
                                        <p>Japan in four Gorgeous <br /> Pokemon-Themed Colors</p>
                                    </a>

                                </div>
                                <div className='carusel-Item' >
                                    <img src={SliderImg4} />
                                    <a href='#' className='PlayA'><PlayCircleOutlined onClick={this.openModal} className='playIcon' style={{ fontSize: '40px', color: 'white' }} /></a>
                                    <span><ClockCircleOutlined className='iconClock' />  Nov 1,2020</span>
                                    <span><EyeOutlined className='iconClock' /> 15k</span>
                                    <span><HeartOutlined className='iconClock' /> 278</span>

                                    <br />
                                    <a className='sliderInfo' href='#'>
                                        <p>Japan in four Gorgeous <br /> Pokemon-Themed Colors</p>
                                    </a>

                                </div>
                                <div className='carusel-Item' >
                                    <img src={SliderImg4} />
                                    <a href='#' className='PlayA'><PlayCircleOutlined onClick={this.openModal} className='playIcon' style={{ fontSize: '40px', color: 'white' }} /></a>
                                    <span><ClockCircleOutlined className='iconClock' />  Nov 1,2020</span>
                                    <span><EyeOutlined className='iconClock' /> 15k</span>
                                    <span><HeartOutlined className='iconClock' /> 278</span>

                                    <br />
                                    <a className='sliderInfo' href='#'>
                                        <p>Japan in four Gorgeous <br /> Pokemon-Themed Colors</p>
                                    </a>

                                </div>
                                <div className='carusel-Item' >
                                    <img src={SliderImg4} />
                                    <a href='#' className='PlayA'><PlayCircleOutlined onClick={this.openModal} className='playIcon' style={{ fontSize: '40px', color: 'white' }} /></a>
                                    <span><ClockCircleOutlined className='iconClock' />  Nov 1,2020</span>
                                    <span><EyeOutlined className='iconClock' /> 15k</span>
                                    <span><HeartOutlined className='iconClock' /> 278</span>

                                    <br />
                                    <a className='sliderInfo' href='#'>
                                        <p>Japan in four Gorgeous <br /> Pokemon-Themed Colors</p>
                                    </a>

                                </div>
                            </Carousel>
                        </div>


                        <div className='bg-black'>

                        </div>
                    </div>
                </div>
                <ModalVideo channel='youtube' isOpen={this.state.isOpen} videoId='L61p2uyiMSo' onClose={() => this.setState({isOpen: false})} />
            </div>



        )
    }
}

export default MyCarusel;